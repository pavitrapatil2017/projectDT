'use strict';

app.service('ChatMsgService', ['$http', '$q','$rootScope','$timeout', function($http, $q,$rootScope,$timeout){
	console.log("ChatMsgService...")
	var service = {}, listener = $q.defer(), socket = {
	      client: null,
	      stomp: null
	    }, messageIds = [];
	    
	    service.RECONNECT_TIMEOUT = 30000;
	    service.SOCKET_URL = "/StudentsMeetControllerRest/chat";
	    service.CHAT_TOPIC = "/topic/message";
	    service.CHAT_BROKER = "/app/chat";
	    
	    service.receive = function() {
	      return listener.promise;
	    };
	    
	    service.send = function(message) {
	      var id = Math.floor(Math.random() * 1000000);
	      socket.stomp.send(service.CHAT_BROKER, {
	        priority: 9
	      }, JSON.stringify({
	        message : message.message,
	        userID : message.userID,
	        chatID : message.chatID,
	        id: id
	      }));
	      messageIds.push(id);
	    };
	    
	    var reconnect = function() {
	      $timeout(function() {
	        initialize();
	      }, this.RECONNECT_TIMEOUT);
	    };
	    
	    var getMessage = function(data) {
	      var message = JSON.parse(data), out = {};
	      out.message = message.message;
	      out.userID = message.userID;
	      out.chatID = message.chatID;
	      out.time = new Date(message.time);
	      if (_.includes(messageIds, message.id)) {
	        out.self = true;
	        messageIds = _.remove(messageIds, message.id);
	      }
	      return out;
	    };
	    
	    var startListener = function() {
	      socket.stomp.subscribe(service.CHAT_TOPIC, function(data) {
	        listener.notify(getMessage(data.body));
	      });
	    };
	    
	    var initialize = function() {
	      socket.client = new SockJS(service.SOCKET_URL);
	      socket.stomp = Stomp.over(socket.client);
	      socket.stomp.connect({}, startListener);
	      socket.stomp.onclose = reconnect;
	    };
	    
	    initialize();
	    return service;
}])