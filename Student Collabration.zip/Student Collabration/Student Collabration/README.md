# CLBSiteSTMT

Developed using AngularJs,Spring,Hibernate and Rest Services STMT is a simple website which has the Blog , Forum, Chat modules in
it with additional User operations.
