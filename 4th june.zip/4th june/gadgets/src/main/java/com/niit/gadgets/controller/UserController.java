package com.niit.gadgets.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.gadgets.dao.CategoryDAO;
import com.niit.gadgets.dao.UserDAO;
import com.niit.gadgets.model.User;

@Controller
public class UserController {

	@Autowired
	UserDAO userDao;
	
	@Autowired
	CategoryDAO categoryDao;
	
	public void UserDAO(UserDAO userDao)
	{
		this.userDao=userDao;
	}
	
	@ModelAttribute
	   public void addAttributes(Model model)
	   {
		   model.addAttribute("list",categoryDao.getAllCategories());
	   }
	
	@RequestMapping(value="/register",method=RequestMethod.GET)
	public String reg()
	{
		return "registration";
	}
	@RequestMapping(value="/regpage")
	public ModelAndView reg1(HttpServletRequest request)
	{System.out.println("------------------------------------");
        String mail=request.getParameter("email");
        String name=request.getParameter("username");
		String add=request.getParameter("address");
		int age=Integer.parseInt(request.getParameter("age"));
		String phone=request.getParameter("phone");
		String pass=request.getParameter("password");
		System.out.println("haoiii"+name+"mail"+"add"+add+"age"+age+"phone"+phone+"pass"+pass);
		User u=new User(mail,name,age,phone,add,pass,"USER_ROLE");
		/*u.setU_mail(mail);
		u.setU_name(name);
		u.setAddress(add);
		u.setAge(age);
		u.setPhone(phone);
		u.setRole("USER");
		u.setU_password(pass);*/
		userDao.persist(u);
		
		ModelAndView mv = new ModelAndView("index");
		
		return mv;
	}
}