package com.niit.gadgets.daoimpl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.gadgets.dao.CartDAO;
import com.niit.gadgets.model.Cart;
import com.niit.gadgets.model.Product;

@Repository
public class CartDAOImpl implements CartDAO{

	public void persist(Cart c) {
		// TODO Auto-generated method stub
		
	}

	public void update(Cart p) {
		// TODO Auto-generated method stub
		
	}

	public Product findById(Cart id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(Cart p) {
		// TODO Auto-generated method stub
		
	}

	public List<Cart> getCarts() {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}



	
	
}
