package com.niit.gadgets.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Cart 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int cart_id;
	@Column private int s_id;
	@Column private int c_price;
	@Column private int c_quantity;
	@Column private int c_status;
	private Supplier supplier;
	private Product product;
	public Cart(int cart_id, int s_id, int c_price, int c_quantity, int c_status, Supplier supplier, Product product) {
		super();
		this.cart_id = cart_id;
		this.s_id = s_id;
		this.c_price = c_price;
		this.c_quantity = c_quantity;
		this.c_status = c_status;
		this.supplier = supplier;
		this.product = product;
	}
	public int getCart_id() {
		return cart_id;
	}
	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}
	public int getS_id() {
		return s_id;
	}
	public void setS_id(int s_id) {
		this.s_id = s_id;
	}
	public int getC_price() {
		return c_price;
	}
	public void setC_price(int c_price) {
		this.c_price = c_price;
	}
	public int getC_quantity() {
		return c_quantity;
	}
	public void setC_quantity(int c_quantity) {
		this.c_quantity = c_quantity;
	}
	public int getC_status() {
		return c_status;
	}
	public void setC_status(int c_status) {
		this.c_status = c_status;
	}
	public Supplier getSupplier() {
		return supplier;
	}
	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	
	

}
	