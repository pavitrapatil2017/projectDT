package com.niit.gadgets.daoimpl;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.niit.gadgets.dao.ProductDAO;
import com.niit.gadgets.model.Category;
import com.niit.gadgets.model.Product;

@Repository
public class ProductDAOImpl implements ProductDAO
{

	@Autowired
	private SessionFactory sessionFactory;
	 
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}
	
	public void persist(Product p) 
	{
		Session s=sessionFactory.openSession();
		s.beginTransaction();
		s.save(p);
		s.getTransaction().commit();
		s.close();
		
		}

	public void update(Product p) {
		// TODO Auto-generated method stub
		System.out.println("the implement of update");
		Session s=sessionFactory.openSession();
		s.beginTransaction();
		s.update(p);
		s.getTransaction().commit();
		s.close();
		
	}

	public Product findById(int id) {
		// TODO Auto-generated method stub
		System.out.println("in find by id");
		return (Product)sessionFactory.openSession().get(Product.class,id);
	
	}

	public void delete(Product p) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.openSession();
		s.beginTransaction();
		s.delete(p);
		s.getTransaction().commit();
		s.close();
		
	}

	public List<Product> getAllProducts() {
		
		Session sf =sessionFactory.openSession();
		sf.beginTransaction();
		Query query = sf.createQuery("from Product");
		List<Product> list2=query.list();
		System.out.println(list2);
		sf.getTransaction().commit();
			return list2;
		}

	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	public List<Product> getAllProductByCatId(int cid) {
		System.out.println("daoimplllllllllllllllllll"+cid);
		// TODO Auto-generated method stub
		Session s=sessionFactory.openSession();
		
		List<Product> results =s.createQuery("from Product where c_id="+cid).list();
		s.close();
		
		return results;
	}
	
	
}
