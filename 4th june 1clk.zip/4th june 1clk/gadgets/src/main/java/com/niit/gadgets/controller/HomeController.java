package com.niit.gadgets.controller;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
//import java.io.BufferedOutputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.*;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import com.niit.gadgets.dao.CategoryDAO;
import com.niit.gadgets.dao.ProductDAO;
//import com.niit.gadgets.dao.ProductDAO;
//import com.niit.gadgets.daoimpl.CategoryDAOImpl;
import com.niit.gadgets.model.Category;
import com.niit.gadgets.model.Product;
//import com.niit.gadgets.model.Product;
import com.niit.gadgets.model.Supplier;
import com.niit.gadgets.dao.SupplierDAO;

@Controller
public class HomeController {
	
	@Autowired
	ProductDAO productDao;
	public void ProductDAO(ProductDAO productDao)
	{
		this.productDao=productDao;
	}
	
	@Autowired
	CategoryDAO categoryDao;
	  public void CategoryDAO(CategoryDAO categoryDao)
	{
		this.categoryDao=categoryDao;
	}
	
	@Autowired
	SupplierDAO supplierDao;
       public void SupplierDAO(SupplierDAO supplierDao)
	{
		this.supplierDao=supplierDao;
	}
	
	
   @RequestMapping("/")
	public ModelAndView index() { 
	   ModelAndView mv = new ModelAndView("index");
		mv.addObject("catlist",categoryDao.getAllCategories());
		return mv;
	}
   @RequestMapping("/noAccessPage")
  	public ModelAndView index1() { 
  	   ModelAndView mv = new ModelAndView("noAccessPage");
  		return mv;
  	}
   
   @ModelAttribute
   public void addAttributes(Model model)
   {
	   model.addAttribute("list",categoryDao.getAllCategories());
   }
   
   @RequestMapping("/index")
   public String home()
   {
	   return "index";
   }
   
	@RequestMapping("/productDetails")
	public ModelAndView product() {

		ModelAndView mv = new ModelAndView("productDetails");
		
		return mv;
	}
	
	@RequestMapping(value="/admin/DressProductDetails")
	public String details()
	{
		return "DressProductDetails";
	}
	
	@RequestMapping(value="/NeckProductDetails")
	public String details1()
	{
		return "NeckProductDetails";
	}
	
	@RequestMapping(value="/SarryProductDetails")
	public String details2()
	{
		return "SarryProductDetails";
	}
	
	@RequestMapping("/category")
	public ModelAndView category() { 
		ModelAndView mv = new ModelAndView("ProductTable");
		
		return mv;
	}
	

	@RequestMapping("/admin/adding")
	public ModelAndView adding(){
		List<Category> list=categoryDao.getAllCategories();
		List<Supplier> list1=supplierDao.getAllSuppliers();
		ModelAndView m = new ModelAndView("adding");
		m.addObject("list",list);
		m.addObject("slist",list1);
		return m;
	    		 }
	/*@RequestMapping("/addingp")
	public ModelAndView addingp(){
	
	List<Category> list=categoryDao.getAllCategories();
	List<Supplier> list1=supplierDao.getAllSuppliers();
	ModelAndView m = new ModelAndView("addingp");
	m.addObject("list",list);
	m.addObject("slist",list1);
	     return m;
	    		 }
	@RequestMapping("/addings")
	public ModelAndView addings(){
		ModelAndView m = new ModelAndView("addings");
	     return m;}*/
	    		 
	@RequestMapping("user/categorylist")
	public ModelAndView adding1(){
		List<Category> list=categoryDao.getAllCategories();
		ModelAndView m = new ModelAndView("categorylist");
		m.addObject("list", list);
	     return m;
	    		 }
	@RequestMapping("user/supplierlist")
	public ModelAndView adding2(){
		List<Supplier> list=supplierDao.getAllSuppliers();
		ModelAndView m = new ModelAndView("supplierlist");
		m.addObject("list", list);
	     return m;
	    		 }
	//@RequestMapping("/productlist")
	@RequestMapping("admin/productlist")
	public ModelAndView adding3(){
		List<Product> list=productDao.getAllProducts();
		ModelAndView m = new ModelAndView("productlist");
		m.addObject("list", list);
	     return m;
	    		 }
	//@RequestMapping("/FilteredProductList")
	@RequestMapping("FilteredProductList")
	public ModelAndView FilteredProductList(HttpServletRequest request)
	{
		/*
		 List<Product> list=productDao.getFilterProducts(Integer.valueOf(request.getParameter("id")));
		//List<Product> list=productDao.getProducts();
		ModelAndView mv = new ModelAndView("productFilter");	
		mv.addObject("list",list);
		return mv;
		 */
		
		int catid=Integer.parseInt(request.getParameter("cid"));
		List<Product> list=productDao.getAllProductByCatId(catid);
		ModelAndView m=new ModelAndView("FilteredProductList");
		m.addObject("list",list);
		return m;
	}
/*	@RequestMapping("filteredproductDetails")
	public ModelAndView filprodDetails(HttpServletRequest request)
	{
		int p_id=Integer.parseInt(request.getParameter("cid"));
	    Product list=productDao.findById(p_id);
	    ModelAndView mv=new ModelAndView("filteredproductDetails");
	    mv.addObject("list",list);
		return mv;
	}
	@RequestMapping("/user/cart")
	public ModelAndView cart()
	{
		ModelAndView mv=new ModelAndView("Cart");
		return mv;
	}
	*/
	@RequestMapping("/login")
	public ModelAndView login()
	{
		ModelAndView m=new ModelAndView("login");
		return m;
	}
		
	
	
	//@RequestMapping("/add_category")
	@RequestMapping("/admin/add_category")
	public ModelAndView add_category(HttpServletRequest request)
	{
		
		int c_id=Integer.valueOf(request.getParameter("C_ID"));
		String str=request.getParameter("C_NAME");
		System.out.println(c_id+str);
		Category cat = new Category(c_id, str);
		categoryDao.persist(cat);
		List<Category> list=categoryDao.getAllCategories();
		List<Supplier> list1=supplierDao.getAllSuppliers();
		ModelAndView m = new ModelAndView("adding");
		m.addObject("list",list);
		m.addObject("slist",list1);
		return m;
		
	    		 }
	//@RequestMapping("/add_supplier")	 
	@RequestMapping("/admin/add_supplier")
	public ModelAndView add_supplier(HttpServletRequest request)
	{
		
		int s_id=Integer.valueOf(request.getParameter("S_ID"));
		String str=request.getParameter("S_NAME");
		System.out.println(s_id+str);
		Supplier sap = new Supplier(s_id, str);
		supplierDao.persist(sap);
		List<Category> list=categoryDao.getAllCategories();
		List<Supplier> list1=supplierDao.getAllSuppliers();
		ModelAndView m = new ModelAndView("adding");
		m.addObject("list",list);
		m.addObject("slist",list1);
		return m;
	    		 }
	//@RequestMapping("/add_product")
	@RequestMapping("/admin/add_product")
	public String add_product(@RequestParam("file") MultipartFile file ,HttpServletRequest request)
	{
	
		System.out.println(request.getParameter("pId"));
		System.out.println(request.getParameter("pName"));
		System.out.println(request.getParameter("pPrice"));
		System.out.println(request.getParameter("pCategory"));
		System.out.println(request.getParameter("pSupplier"));
		//System.out.println(request.getParameter("pImg"));
		Product product=new Product();
		product.setP_id(Integer.parseInt(request.getParameter("pId")));
		product.setP_name(request.getParameter("pName"));
		product.setP_price(Integer.parseInt(request.getParameter("pPrice")));
		product.setCategory(categoryDao.findById(Integer.parseInt(request.getParameter("pCategory").toString())));
		product.setSupplier(supplierDao.findById(Integer.parseInt(request.getParameter("pSupplier").toString())));
	//	product.setP_image(request.getParameter("pImg"));
		String originalfile = file.getOriginalFilename();
		product.setP_image(originalfile);
		productDao.persist(product);
		String filepath = request.getSession().getServletContext().getRealPath("/") + "/resources/product/" + file.getOriginalFilename();
		
		System.out.println(filepath);
		try {
			byte imagebyte[] = file.getBytes();
			BufferedOutputStream fos = new BufferedOutputStream(new FileOutputStream(filepath));
			fos.write(imagebyte);
			fos.close();
			} catch (IOException e) {
			e.printStackTrace();
			} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		
		//ModelAndView m1 = new ModelAndView("addingp");
	     return "index";
	   }
	//@RequestMapping(value="/product_delete")
	@RequestMapping(value="/admin/product_delete")
	public ModelAndView deleteProduct(HttpServletRequest request){
		
		Product p=productDao.findById(Integer.valueOf(request.getParameter("id")));
		System.out.print(p);
	productDao.delete(p);
	List<Product> list=productDao.getAllProducts();
	ModelAndView mv = new ModelAndView("productlist");	
	mv.addObject("list",list);
	return mv;
	}
	
	//@RequestMapping(value="/product_edit")
	@RequestMapping(value="/admin/product_edit")
	public ModelAndView editProducts(HttpServletRequest request){	
	int id=Integer.parseInt(request.getParameter("id"));
	System.out.println(id);
	ModelAndView mv=new ModelAndView("productEdit");
	List<Category> list=categoryDao.getAllCategories();
	List<Supplier> slist=supplierDao.getAllSuppliers();	
	mv.addObject("product",productDao.findById(id) );	
	mv.addObject("slist", slist);
	mv.addObject("clist", list);
	return mv;
	}
	
	//@RequestMapping(value = "/product_update", method=RequestMethod.POST)	
@RequestMapping(value = "/admin/product_update", method=RequestMethod.POST)
	public  ModelAndView updateProduct(@RequestParam("file") MultipartFile file ,HttpServletRequest request) 
	{ 
		System.out.println("in Products Controller");
		int id=Integer.valueOf(request.getParameter("p_id"));
		
		String pname=request.getParameter("p_name");
		String pdesc=request.getParameter("p_desc");
		int price=Integer.valueOf(request.getParameter("p_price"));
		int cid=Integer.valueOf(request.getParameter("cidname"));
		int sid=Integer.valueOf(request.getParameter("sidname"));
		Category c=categoryDao.findById(cid);
		Supplier s=supplierDao.findById(sid);
		Product p=new Product();
		p.setCategory(c);
		p.setP_description(pdesc);
		p.setP_name(pname);
		p.setP_price(price);
		p.setP_id(id);	
		String originalfile = file.getOriginalFilename();
		p.setP_image(originalfile);
		p.setSupplier(s);
		productDao.update(p);
		String filepath = request.getSession().getServletContext().getRealPath("/") + "/resources/product/" + file.getOriginalFilename();
		
		System.out.println(filepath);
		try {
			byte imagebyte[] = file.getBytes();
			BufferedOutputStream fos = new BufferedOutputStream(new FileOutputStream(filepath));
			fos.write(imagebyte);
			fos.close();
			} catch (IOException e) {
			e.printStackTrace();
			} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		
	List<Product> list=productDao.getAllProducts();
		ModelAndView mv = new ModelAndView("productlist");
			mv.addObject("list", list);
		return mv;
	}

	}

