'use strict';
 
app.controller('UserController', ['$scope', 'UserService', '$location', '$rootScope', '$cookieStore', '$http','$route', function ($scope, UserService, $location, $rootScope, $cookieStore, $http,$route) {
 
    console.log("User Controller...");
 
    $scope.user = {
        email: '',
        fname: '',
        lname: '',
        mobile: '',
        password: '',
        role: '',
        status: '',
        isonline: '',
        errorCode: '',
        errorMessage: ''
    };
   
    $scope.sentrequests = [];
 
    $scope.users = [];
 
    $scope.userlist = [];
   
    $scope.fetchAllUsers = function () {
        console.log("fetchAllUsers...");
        UserService.fetchAllUsers()
                .then(
                        function (d) {
                            $scope.users = d;
                        },
                        function (errResponse) {
                            console
                                    .error("Error while fetching Users..");
                        });
    };
 
    $scope.createUser = function (user) {
        console.log("create user..");
        UserService
                .createUser(user)
                .then(
 
                        $scope.fetAllUsers,
                        function (errResponse) {
                            console
                                    .error("Error while creating user...");
                        });
    };
 
    $scope.authenticate = function (user) {
        console.log("authentication..");
        UserService
                .authenticate(user)
                .then(
 
                        function (d) {
                            $scope.user = d;
                            console
                                    .log("user.errorCode :"
                                            + $scope.user.errorCode);
                            if ($scope.user.errorCode == "404") {
                                alert("Invalid credentials..Please Try again Later");
                                $scope.user.email = '';
                                $scope.user.password = '';
                            } else {
                                console
                                        .log("Valid Credentials..Navigating To Home Page...");
 
                                $rootScope.currentUser = $scope.user;
                                $rootScope.logincheck = true;
                                $http.defaults.headers.common['Authorization'] = 'Basic' + $rootScope.currentUser;
                                $cookieStore.put('currentUser',$rootScope.currentUser);
                                $cookieStore.put('logincheck',$rootScope.logincheck);
                                if ($rootScope.currentUser.role === "admin") {
                                    $location.path('/sortjob');
                                }
                                else if($rootScope.currentUser.role === "superadmin") {
                                    $location.path('/admin');
                                }
                                else {
                                    $location.path('/home');
                                }
                            }
                        },
                        function (errResponse) {
                            console
                                    .error("Error while authenticating users");
                        });
    };
 
    $scope.logout = function () {
        console.log("logout..");
        $rootScope.currentUser = {};
        $rootScope.logincheck = false;
        $cookieStore
        .put(
                'logincheck',
                $rootScope.logincheck);
        $cookieStore.remove('currentUser');
        UserService.logout();
        $location.path('/');
    };
 
    $scope.login = function () {
        {
            console.log("login validation ???",
                    $scope.user);
            $scope.authenticate($scope.user);
        }
    };
 
    $scope.submit = function () {
        {
            console.log("Saving New User", $scope.user);
            $scope.createUser($scope.user);
        }
        $scope.reset();
    };
 
   $scope.reset = function () {
        $scope.user = {
            email: '',
            fname: '',
            lname: '',
            mobile: '',
            password: '',
            role: '',
            status: '',
            isOnline: '',
            errorCode: '',
            errorMessage: ''
        };
        $scope.myForm.$setPristine();
    };
 
    $scope.setAdmin = function (email) {
        console.log('set admin...');
        UserService.setAdmin(email).then(function (d) {
            $scope.user = d;
            alert("successfully made admin");
            $route.reload();
        },
        function (errResponse) {
            console.error('error making admin in controller...');
        });
    };
 
    $scope.removeAdmin = function (email) {
        console.log('remove admin...');
        UserService.removeAdmin(email).then(function (d) {
            $scope.user = d;
            alert("successfully removed admin");
            $route.reload();
        },
        function (errResponse) {
            console.error('error removing admin in controller...');
        });
    };
   
    $scope.searchAllUsers = function () {
        console.log("searchAllUsers...");
        UserService.searchAllUsers()
                .then(
                        function (d) {
                            $scope.userlist = d;
                            console.log(d);
                           
                        },
                        function (errResponse) {
                            console
                                    .error("Error while fetching Users..");
                        });
    };
   
    $scope.searchSentRequests = function () {
        console.log("searchSentRequests...");
        UserService.searchSentRequests()
                .then(
                        function (d) {
                            $scope.sentrequests = d;
                            console.log(d);
                           
                        },
                        function (errResponse) {
                            console
                                    .error("Error while fetching Users..");
                        });
    };
   
    $scope.sendFriendRequest = function (email) {
        console.log("sendRequest...");
        UserService.sendFriendRequest(email)
                .then(
                        function (d) {
                            $scope.friend = d;
                            $route.reload();
                        },
                        function (errResponse) {
                            console
                                    .error("Error while sending request in controller..");
                        });
    };
   
    $scope.acceptRequest = function (email) {
        console.log("acceptRequest...");
        UserService.acceptRequest(email)
                .then(
                        function (d) {
                            $scope.friend = d;
                            $route.reload();
                        },
                        function (errResponse) {
                            console
                                    .error("Error while accepting request in controller..");
                        });
    };
   
    $scope.rejectRequest = function (email) {
        console.log("rejectRequest...");
        UserService.rejectRequest(email)
                .then(
                        function (d) {
                            $scope.friend = d;
                            $route.reload();
                        },
                        function (errResponse) {
                            console
                                    .error("Error while rejecting request in controller..");
                        });
    };
   
    $scope.unFriend = function (email) {
        console.log("unFriend...");
        UserService.unFriend(email)
                .then(
                        function (d) {
                            $scope.friend = d;
                            $route.reload();
                        },
                        function (errResponse) {
                            console
                                    .error("Error unfriending in controller..");
                        });
    };
   
    $scope.getFriendList = function () {
        console.log("getFriendList...");
        UserService.getFriendList()
                .then(
                        function (d) {
                            $scope.friendlist = d;
                            console.log(d);
                           
                        },
                        function (errResponse) {
                            console
                                    .error("Error while fetching Friendlist..");
                        });
    };
 
}]);
 