package com.niit.collabackEnd.config;

public class App {

}
