package com.niit.collabackEnd.model;

public class Event {

}
