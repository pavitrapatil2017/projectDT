package com.niit.collabackEnd.model;

public class OutputMessage {

}
