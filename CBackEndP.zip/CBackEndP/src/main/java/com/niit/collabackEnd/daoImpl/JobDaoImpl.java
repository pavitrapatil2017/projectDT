package com.niit.collabackEnd.daoImpl;

public class JobDaoImpl {

}
