package com.niit.collabackEnd.dao;

public interface UserDao {

}
