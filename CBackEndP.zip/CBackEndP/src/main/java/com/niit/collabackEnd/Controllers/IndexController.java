package com.niit.collabackEnd.Controllers;

public class IndexController {

}
