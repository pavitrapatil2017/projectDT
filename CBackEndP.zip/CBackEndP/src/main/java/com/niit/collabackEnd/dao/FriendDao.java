package com.niit.collabackEnd.dao;

public interface FriendDao {

}
