package com.niit.collabackEnd.dao;

public interface EventDao {

}
