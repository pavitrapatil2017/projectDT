package com.niit.collabackEnd.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Blog extends BaseDomain{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String blogid;
	
	@Column(name="Bheading")
	private String Bheading;
	
	@Column(name="Bdesc")
	private String Bdesc;
	
	@Column(name="status")
	private String status;
	
	@ManyToOne
	@JoinColumn(name="Userid")
	private User user;
	
	@Column(name="reason")
	private String reason;
	
	@Column(name="posted_dt")
	private Date posted_dt;
	
	public Blog()
	{
		
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Date getPosted_dt() {
		return posted_dt;
	}

	public void setPosted_dt(Date posted_dt) {
		if(posted_dt==null)
		{
			posted_dt= new Date(System.currentTimeMillis());
		}
		this.posted_dt = posted_dt;
	}

	public String getBlogid() {
		return blogid;
	}

	public void setBlogid(String blogid) {
		this.blogid = blogid;
	}

	public String getBheading() {
		return Bheading;
	}

	public void setBheading(String bheading) {
		Bheading = bheading;
	}

	public String getBdesc() {
		return Bdesc;
	}

	public void setBdesc(String bdesc) {
		Bdesc = bdesc;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setUserid(String loggedInUserid) {
		// TODO Auto-generated method stub
		
	}
}
