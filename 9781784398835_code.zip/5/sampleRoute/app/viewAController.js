angular.module('flipFlop')
		.controller('ViewAController',['$scope',function($scope){
			$scope.flip = function(){};
		}]);