angular.module('flipFlop')
		.controller('ViewBController',['$scope',function($scope){
		}]);