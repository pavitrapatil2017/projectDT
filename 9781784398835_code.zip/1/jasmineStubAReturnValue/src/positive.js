var complex = {
	logic : function(){
		//Some Complex Logic
	}
}

var positive = function(value){
	var result = complex.logic(value);

	return result > 0;
};