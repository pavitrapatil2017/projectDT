angular.module('product',[]);
// angular.module('product',['ngMockE2E'])
// 		.run(['$httpBackend',function($httpBackend) {
// 				var testProduct = productDataBuilder().build();
// 				var products = [testProduct];
// 				$httpBackend.whenGET('/products').respond(products);
// 		  	}]);