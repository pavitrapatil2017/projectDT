var pubSub = angular.module('pubSub',[]);

pubSub.controller('TopController',function($scope){
});

pubSub.controller('MiddleController',function($scope){
});

pubSub.controller('BottomController',function($scope){
});