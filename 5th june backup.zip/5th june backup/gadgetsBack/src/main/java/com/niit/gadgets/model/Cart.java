package com.niit.gadgets.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity	
@Table(name="CART")
public class Cart implements Serializable
{

	
	private static final long serialVersionUID = 1L;
	
	@Id
     private int cartid;
	private Product productid;
	private Supplier suplierid;
	private User userid;
	
	private int prices;
	private int quantity;
	private String status;
	
	@Id
	@GeneratedValue
	@Column(name="cartid")//defining the database column
		public int getCartid() {
		return cartid;
	}
	public void setCartid(int cartid) {
		this.cartid = cartid;
	}
	//In One productid display in cart
		@OneToOne
		@JoinColumn(name="p_id")
		public Product getProductid() {
			return productid;
		}
		public void setProductid(Product productid) {
			this.productid = productid;
		}
		/*@OneToOne
		@JoinColumn(name="suplierid")
		public SupplierModel getSuplierid() {
			return suplierid;
		}
		public void setSuplierid(SupplierModel suplierid) {
			this.suplierid = suplierid;
		}*/
		/*@OneToOne
		@JoinColumn(name="userid")
		public UserModel getUserid() {
			return userid;
		}
		public void setUserid(UserModel userid) {
			this.userid = userid;
		}*/
	@Column(name="prices")
	public int getPrices() {
		return prices;
	}
	public void setPrices(int prices) {
		this.prices = prices;
	}
	@Column(name="quantity")
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	/*@Column(name="status")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}*/
	
	public Cart()
	{
		
	}

}


/*import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table
public class Cart 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int cart_id;
	@Column private int s_id;
	@Column private int c_price;
	@Column private int c_quantity;
	@Column private int c_status;
	private Supplier supplier;
	private Product product;
	public Cart(int cart_id, int s_id, int c_price, int c_quantity, int c_status, Supplier supplier, Product product) {
		super();
		this.cart_id = cart_id;
		this.s_id = s_id;
		this.c_price = c_price;
		this.c_quantity = c_quantity;
		this.c_status = c_status;
		this.supplier = supplier;
		this.product = product;
	}
	public int getCart_id() {
		return cart_id;
	}
	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}
	public int getS_id() {
		return s_id;
	}
	public void setS_id(int s_id) {
		this.s_id = s_id;
	}
	public int getC_price() {
		return c_price;
	}
	public void setC_price(int c_price) {
		this.c_price = c_price;
	}
	public int getC_quantity() {
		return c_quantity;
	}
	public void setC_quantity(int c_quantity) {
		this.c_quantity = c_quantity;
	}
	public int getC_status() {
		return c_status;
	}
	public void setC_status(int c_status) {
		this.c_status = c_status;
	}
	public Supplier getSupplier() {
		return supplier;
	}
	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	
	

}
	*/