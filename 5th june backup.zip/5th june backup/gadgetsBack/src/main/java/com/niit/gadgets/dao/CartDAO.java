package com.niit.gadgets.dao;

import java.util.List;

import com.niit.gadgets.model.Cart;
import com.niit.gadgets.model.Product;

public interface CartDAO {

	
	/* public void persist(Cart c);
		
		public void update(Cart p);
		
		public Cart findById(Cart id);
		
		public void delete(Cart p);
		
		public List<Cart> getCarts();
		
		public void deleteAll();
		*/
	 //save
		public void save(Cart cart);
	    //read
			public Cart getId(int id);
			//update
			public void update(Cart cart);
			//deleted
			public void delete(Cart c);
			//Get All
			public List<Cart> getAll();
	
}
