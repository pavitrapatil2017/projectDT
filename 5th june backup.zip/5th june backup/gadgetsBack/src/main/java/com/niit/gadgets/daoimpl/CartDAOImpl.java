package com.niit.gadgets.daoimpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.gadgets.dao.CartDAO; 

import com.niit.gadgets.model.Cart;
import com.niit.gadgets.model.Category;


@Repository
public class CartDAOImpl implements CartDAO{
	

	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}

	public void save(Cart cart1)
	{
		Session s=sessionFactory.openSession();
		s.beginTransaction();
		s.save(cart1);
		s.getTransaction().commit();
		s.close();
		
	}

	public Cart getId(int id) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.openSession();
		Cart t=(Cart)s.get(Cart.class, id);
		return t;
	}

	public void update(Cart cart) {
		// TODO Auto-generated method stub
		
	}

	public void delete(Cart c) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.openSession();
		s.beginTransaction();
		s.delete(c);
		s.getTransaction().commit();
		s.close();
		
	}

	public List<Cart> getAll() {
		// TODO Auto-generated method stub
		Session sf =sessionFactory.openSession();
		sf.beginTransaction();
		Query query = sf.createQuery("from Cart");
		List<Cart> list=query.list();
		System.out.println(list);
		sf.getTransaction().commit();
			return list;
	}

	   
	
	/*@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
	
	public void persist(Cart c) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		
		session.beginTransaction();
		session.save(c);
			session.close();
		
	}

	public void update(Cart p) {
		// TODO Auto-generated method stub
		
	}

	public Cart findById(Cart id) {
		Session s=sessionFactory.openSession();
		Cart t=(Cart)s.get(Cart.class,id);
	 return null;
	}

	public void delete(Cart p) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.openSession();
		s.beginTransaction();
		s.delete(p);
		s.getTransaction().commit();
		s.close();
		
	}

	public List<Cart> getCarts() {
		return null;
	}

	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}*/
	
	
}
