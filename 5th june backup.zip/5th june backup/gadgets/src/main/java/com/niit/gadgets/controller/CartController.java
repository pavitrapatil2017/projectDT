package com.niit.gadgets.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.gadgets.model.Cart;
import com.niit.gadgets.model.Product;
import com.niit.gadgets.dao.*;

@Controller
public class CartController {

	@Autowired
	ProductDAO productDao;
	
	public void ProductDAO(ProductDAO productDao)
	{
		this.productDao=productDao;
	}
	
	
	@Autowired
	CartDAO cartDao;
	
	public void CartDAO(CartDAO cartDao)
	{
		this.cartDao=cartDao;
	}
	
	@RequestMapping("/RenProductDetails")
	public ModelAndView addCarttable(HttpServletRequest request) 
	{
		
		int id=Integer.valueOf(request.getParameter("prodid"));
		
		int quan=Integer.valueOf(request.getParameter("prodquantity"));
		
		int price=Integer.valueOf(request.getParameter("prodprice"));
		/*int uid=Integer.valueOf(request.getParameter("userid"));
		int sid=Integer.valueOf(request.getParameter("suplierid"));*/
		
		/*UserModel c=user1.findById(uid);
		SupplierModel s=supplierDAO.findById(sid);*/
		System.out.println(""+id+""+quan+""+price);
		Product p=productDao.findById(id);
		Cart g=new Cart();
		g.setPrices(price);
		g.setQuantity(quan);
		g.setProductid(p);
		/*g.setSuplierid(s);
		g.setUserid(c);*/
		
		
		cartDao.save(g);
		
		ModelAndView mv = new ModelAndView("RenProductDetails");
		mv.addObject("product", p);
		return mv;
	}
	@RequestMapping("/ViewCart")
	public ModelAndView viewCart(){
		
		ModelAndView mv=new ModelAndView("ViewCart");
		List<Cart> cartList=cartDao.getAll();
		
		mv.addObject("cartlist", cartList);
		return mv;
	}
	@RequestMapping("/cart_delete")
	public ModelAndView editCart(HttpServletRequest request)
	{
		int cid=Integer.valueOf(request.getParameter("id"));
		Cart c=cartDao.getId(cid);
		cartDao.delete(c);
		
		ModelAndView mv=new ModelAndView("ViewCart");
		List<Cart> cartList=cartDao.getAll();
		
		mv.addObject("cartlist", cartList);
		return mv;
	}
	@RequestMapping("/addCart")
	public ModelAndView addCart(HttpServletRequest request){
		int id=Integer.valueOf(request.getParameter("id"));
		int q=Integer.valueOf(request.getParameter("q"));
		
		Product p=productDao.findById(id);
		int price=p.getP_price();
		Cart c=new Cart();
	   c.setPrices(price);
		c.setQuantity(q);
		
		c.setProductid(p);
		
		
		
		cartDao.save(c);
		
		System.out.println(c);
		
		ModelAndView mv=new ModelAndView("ViewCart");
		List<Cart> cartList=cartDao.getAll();
		
		mv.addObject("cartlist", cartList);
		return mv;
		
	}

}
	

