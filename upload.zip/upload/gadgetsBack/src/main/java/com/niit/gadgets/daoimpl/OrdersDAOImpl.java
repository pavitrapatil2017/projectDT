package com.niit.gadgets.daoimpl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.gadgets.dao.OrdersDAO;
import com.niit.gadgets.model.Category;
import com.niit.gadgets.model.Orders;

@Repository
public class OrdersDAOImpl implements OrdersDAO{

	public void persist(Orders o) {
		// TODO Auto-generated method stub
		
	}

	public void update(Orders o) {
		// TODO Auto-generated method stub
		
	}

	public Category findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(Orders o) {
		// TODO Auto-generated method stub
		
	}

	public List<Orders> getAllOrders() {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

}
